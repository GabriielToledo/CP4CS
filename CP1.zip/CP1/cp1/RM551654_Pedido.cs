using System.ComponentModel.DataAnnotations;
using System;

public class RM551654_Pedido
{
    [Key]
    public int idPedido { get; set; }
    public DateTime dataPedido { get; set; }
    public decimal valorTotal { get; set; }
}