using System.ComponentModel.DataAnnotations;

public class RM551654_Fornecedor
{
    [Key]
    public int idFornecedor { get; set; }
    public string nrCEP { get; set; }
    public string dsEndereco { get; set; }
    public string Estado { get; set; }
    public string Cidade { get; set; }
}