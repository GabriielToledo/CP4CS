using System.ComponentModel.DataAnnotations;

public class RM551654_Produto
{
    [Key]
    public int idProduto { get; set; }
    public string nmProduto { get; set; }
    public decimal preco { get; set; }
}