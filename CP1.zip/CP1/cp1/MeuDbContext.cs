using Microsoft.EntityFrameworkCore;

public class MeuDbContext : DbContext
{
    public DbSet<RM551654_Fornecedor> Fornecedores { get; set; }
    public DbSet<RM551654_Produto> Produtos { get; set; }
    public DbSet<RM551654_Pedido> Pedidos { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        // Substitua a string de conexão pela sua. Exemplo abaixo.
        var connectionString = "DATA SOURCE=oracle.fiap.com.br:1521/ORCL;USER ID=RM551654;PASSWORD=010804;";
        optionsBuilder.UseOracle(connectionString);
    }
}